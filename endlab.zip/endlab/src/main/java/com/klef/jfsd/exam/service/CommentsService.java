package com.klef.jfsd.exam.service;

import com.klef.jfsd.exam.model.Comment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class CommentsService {
    private final RestTemplate restTemplate = new RestTemplate();
    private final String apiUrl = "https://jsonplaceholder.typicode.com/comments";

    public List<Comment> getAllComments() {
        Comment[] commentsArray = restTemplate.getForObject(apiUrl, Comment[].class);
        return Arrays.asList(commentsArray); // Convert array to List
    }
}
